# Olympic-Data-Analysis
Analysis data using different function and give output in the form of data charts and heatmaps
<br>
Author - Sarthak Dhiman
